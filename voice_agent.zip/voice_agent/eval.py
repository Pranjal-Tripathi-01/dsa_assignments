# viva_evaluator.py
import asyncio
import json
import os
from datetime import datetime
from typing import Literal

from google import genai
from google.genai import types
from pydantic import BaseModel, ConfigDict, Field

MODEL = os.getenv("GEMINI_MODEL", "gemini-3.1-flash-lite")
MARKS_PER_QUESTION = 1.0

client = genai.Client(api_key="AQ.Ab8RN6J86-p1B8fdSJm6_Y9beSXe2kLUqMKnPBAjZqR8-u9d1A")

Status = Literal["correct", "partially_correct", "incorrect", "not_answered"]


# =====================================================================
# 1) Schema the LLM must follow (sent to Gemini as response_schema)
# =====================================================================
class QuestionEvaluation(BaseModel):
    question_number: int
    topic: str = Field(description="Short syllabus topic, e.g. 'Components of food'")
    question: str = Field(description="The core question only, without greetings or hints")
    student_answer: str = Field(description="Student's final answer(s), summarised. Empty if none")
    status: Status
    marks_awarded: float = Field(description="1.0 correct, 0.5 partially correct, 0.0 otherwise")
    feedback: str = Field(description="One or two sentences on what was right or wrong")


class ModelEvaluation(BaseModel):
    total_questions_planned: int = Field(
        description="Number of questions the examiner said the viva would have"
    )
    questions: list[QuestionEvaluation] = Field(
        description="One entry for each question the examiner actually asked"
    )
    strong_topics: list[str]
    weak_topics: list[str]
    remarks: str = Field(description="3-5 sentence teacher-style remark about the student")


# =====================================================================
# 2) Fixed final output schema (built and validated in code)
# =====================================================================
class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Marks(_Strict):
    obtained: float
    total: float
    percentage: float


class QuestionsSummary(_Strict):
    planned: int
    asked: int
    correct: int
    partially_correct: int
    incorrect: int
    not_answered: int


class TotalTime(_Strict):
    total_seconds: int
    formatted: str


class VivaReport(_Strict):
    session_id: str | None
    student_name: str
    student_class: str | None
    subject: str | None
    marks: Marks
    questions_summary: QuestionsSummary
    total_time: TotalTime
    strong_topics: list[str]
    weak_topics: list[str]
    remarks: str
    question_breakdown: list[QuestionEvaluation]


SYSTEM_PROMPT = """
You are an experienced school teacher and oral (viva) examiner. You will receive a JSON
record of a viva session: class, subject, student name and a transcript of the conversation
between the "examiner" and the "student". Evaluate the student's performance strictly from
the transcript.

HOW TO READ THE TRANSCRIPT
- The transcript is the single source of truth.
- A "question" is a new syllabus question the examiner asks (e.g. "Question one",
  "For our second question", "Now, for your third question"). Hints, rephrasings and
  follow-ups on the same question belong to that same question. They are NOT new questions.
- Read the examiner's opening message to find how many questions were planned
  (e.g. "five questions"). Put this in total_questions_planned.
- If the session ends before the student answers the last asked question, mark that
  question "not_answered". Do not evaluate questions that were never asked.

MARKING RULES (per question, maximum 1 mark)
- correct (1.0): the student gives the expected concept or term accurately, in their own
  words, and without needing the answer to be revealed.
- partially_correct (0.5): the student shows some understanding but the answer is incomplete,
  vague, or only gets there after a hint.
- incorrect (0.0): the answer is wrong or off-target, the student says they don't know, or
  the student asks the examiner to tell them the answer.
- not_answered (0.0): the question was asked but the student never replied.
- Do NOT award marks for information the examiner supplied, only for what the student said.
- Answers that are related but do not answer the question (e.g. naming foods when asked for
  nutrients) are incorrect or at most partially correct, depending on the depth of
  understanding shown.
- Judge by the expected knowledge of the stated class level. Be fair, not harsh. Ignore
  minor grammar or speech-to-text errors if the meaning is clear.

TOPICS
- Give each question a short syllabus topic label.
- strong_topics: topics where the student answered correctly and confidently.
- weak_topics: topics where the student was incorrect, partially correct, or didn't know.
- Only list topics from questions actually asked. If there is no evidence, return an empty
  list. Never invent topics.

REMARKS
- Write 3-5 sentences about the student in the third person, as a teacher would write on a
  report card.
- Mention concrete evidence (what they got right or wrong), the revision they should do, and
  one encouraging note.
- If the session ended early or was incomplete, mention that this limits the assessment.
- Keep the tone supportive and professional.

Return ONLY JSON that conforms to the provided schema.
""".strip()


def _duration(started_at: str, ended_at: str) -> TotalTime:
    seconds = max(
        0,
        int((datetime.fromisoformat(ended_at) - datetime.fromisoformat(started_at)).total_seconds()),
    )
    minutes, secs = divmod(seconds, 60)
    return TotalTime(total_seconds=seconds, formatted=f"{minutes}m {secs}s")


async def evaluate_viva_session(json_path: str) -> dict:
    """Read a viva session JSON file, evaluate it with Gemini, return a fixed-schema dict."""
    with open(json_path, "r", encoding="utf-8") as f:
        session = json.load(f)

    student_name = session.get("student_name") or "Student"
    payload = {
        "student_name": student_name,
        "class": session.get("class"),
        "subject": session.get("subject"),
        "transcript": [
            {"role": t["role"], "text": t["text"]} for t in session.get("transcript", [])
        ],
    }

    chat = client.aio.chats.create(
        model=MODEL,
        config=types.GenerateContentConfig(
            system_instruction=SYSTEM_PROMPT,
            response_mime_type="application/json",
            response_schema=ModelEvaluation,  # enforces structured output
            temperature=0.2,
        ),
    )
    response = await chat.send_message(
        "Evaluate this viva session:\n" + json.dumps(payload, ensure_ascii=False, indent=2)
    )
    ev: ModelEvaluation = response.parsed or ModelEvaluation.model_validate_json(response.text)

    # Deterministic parts are computed in code, not by the LLM.
    asked = len(ev.questions)
    planned = max(ev.total_questions_planned, asked)
    total_marks = planned * MARKS_PER_QUESTION
    obtained = sum(q.marks_awarded for q in ev.questions)

    def count(status: str) -> int:
        return sum(q.status == status for q in ev.questions)

    report = VivaReport(
        session_id=session.get("session_id"),
        student_name=student_name,
        student_class=session.get("class"),
        subject=session.get("subject"),
        marks=Marks(
            obtained=obtained,
            total=total_marks,
            percentage=round(obtained / total_marks * 100, 1) if total_marks else 0.0,
        ),
        questions_summary=QuestionsSummary(
            planned=planned,
            asked=asked,
            correct=count("correct"),
            partially_correct=count("partially_correct"),
            incorrect=count("incorrect"),
            not_answered=count("not_answered") + (planned - asked),
        ),
        total_time=_duration(session["started_at"], session["ended_at"]),
        strong_topics=ev.strong_topics,
        weak_topics=ev.weak_topics,
        remarks=ev.remarks,
        question_breakdown=ev.questions,
    )
    return report.model_dump()


# if __name__ == "__main__":
#     import sys

#     result = asyncio.run(evaluate_viva_session(sys.argv[1]))
#     print(json.dumps(result, indent=2, ensure_ascii=False))