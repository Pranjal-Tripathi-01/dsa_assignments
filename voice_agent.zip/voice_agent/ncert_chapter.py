"""Look up NCERT chapter names by class and subject.

Usage:
    from ncert_chapters import get_chapters
    get_chapters(8, "science")            # -> list of chapter titles
    get_chapters("VIII", "SST")           # aliases and roman numerals work
    get_chapters(8, "english", with_numbers=True)
"""
import json
import re
from pathlib import Path

CATALOGUE_PATH = Path(__file__).with_name("ncert_catalogue.json")

_SUBJECT_ALIASES = {
    "english": "english",
    "science": "science",
    "social science": "social science",
    "social studies": "social science",
    "social": "social science",
    "sst": "social science",
    "sst.": "social science",
}

_ROMAN = {"i": 1, "ii": 2, "iii": 3, "iv": 4, "v": 5, "vi": 6, "vii": 7,
          "viii": 8, "ix": 9, "x": 10, "xi": 11, "xii": 12}

with open(CATALOGUE_PATH, encoding="utf-8") as _f:
    _CATALOGUE = json.load(_f)


def _normalize_class(value) -> str:
    text = str(value).strip().lower()
    text = re.sub(r"^(class|grade|std|standard)\s*", "", text)
    text = re.sub(r"(st|nd|rd|th)$", "", text)
    if text in _ROMAN:
        return str(_ROMAN[text])
    if text.isdigit():
        return str(int(text))
    raise ValueError(f"Unrecognised class: {value!r}")


def _normalize_subject(value) -> str:
    text = re.sub(r"[\s_\-]+", " ", str(value).strip().lower())
    if text in _SUBJECT_ALIASES:
        return _SUBJECT_ALIASES[text]
    raise ValueError(f"Unrecognised subject: {value!r}")


def get_chapters(class_, subject, with_numbers: bool = False):
    """Return the chapter names for a class and subject.

    Args:
        class_: 8, "8", "VIII", "Class 8", ...
        subject: "english", "science", "social science" (also "sst",
                 "social_science", "Social Studies", ...)
        with_numbers: if True, return [(number, title), ...] instead of titles.

    Raises:
        ValueError: if the class or subject is not in the catalogue.
    """
    cls = _normalize_class(class_)
    subj = _normalize_subject(subject)

    if cls not in _CATALOGUE:
        available = sorted(k for k in _CATALOGUE if k != "_meta")
        raise ValueError(f"Class {cls} is not in the catalogue. Available: {available}")
    if subj not in _CATALOGUE[cls]:
        raise ValueError(
            f"Subject {subj!r} is not available for class {cls}. "
            f"Available: {sorted(_CATALOGUE[cls])}"
        )

    chapters = _CATALOGUE[cls][subj]["chapters"]
    if with_numbers:
        return [(c["number"], c["title"]) for c in chapters]
    return [c["title"] for c in chapters]


def get_book_name(class_, subject) -> str:
    """Return the NCERT textbook title for a class and subject."""
    return _CATALOGUE[_normalize_class(class_)][_normalize_subject(subject)]["book"]

print(get_chapters(8, "english"))