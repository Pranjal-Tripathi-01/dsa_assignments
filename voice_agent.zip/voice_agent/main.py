import base64
import json
import os
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

import edge_tts
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from google import genai
from google.genai import types
from eval import evaluate_viva_session

# ==========================
# Configuration
# ==========================

API_KEY = "AQ.Ab8RN6J86-p1B8fdSJm6_Y9beSXe2kLUqMKnPBAjZqR8-u9d1A"
MODEL = "gemini-3.1-flash-lite"
END_PHRASE = "that concludes the viva"

TTS_VOICE = "en-IN-NeerjaNeural"   # male: "en-IN-PrabhatNeural"
TTS_RATE = "-5%"

client = genai.Client(api_key=API_KEY)

BASE_DIR = Path(__file__).resolve().parent
SESSIONS_DIR = BASE_DIR / "sessions"
SESSIONS_DIR.mkdir(parents=True, exist_ok=True)


# ==========================
# Session record helpers
# ==========================

def _ts() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_session_record(session_id: str, cls: str, subject: str) -> dict:
    return {
        "session_id": session_id,
        "class": cls,
        "subject": subject,
        "started_at": _ts(),
        "ended_at": None,
        "transcript": [],   # { role, text, timestamp }
        "answers": [],      # { question, answer, timestamp }
    }


def save_session(record: dict):
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)   # recreate if deleted
    path = SESSIONS_DIR / f"{record['session_id']}.json"
    with open(path, "w") as f:
        json.dump(record, f, indent=2)
    print(f"[✓] Session saved → {path}")


# ==========================
# Text-to-speech
# ==========================

async def synthesize(text: str) -> bytes:
    communicate = edge_tts.Communicate(text, TTS_VOICE, rate=TTS_RATE)
    audio = bytearray()
    async for chunk in communicate.stream():
        if chunk["type"] == "audio":
            audio.extend(chunk["data"])
    return bytes(audio)


# ==========================
# FastAPI app
# ==========================

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("Viva server ready.")
    yield
    print("Viva server shutting down.")


app = FastAPI(title="Viva Voce AI Server", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==========================
# REST endpoints
# ==========================

@app.get("/")
async def root():
    return {"status": "ok", "message": "Viva Voce server is running"}


@app.get("/sessions")
async def list_sessions():
    sessions = []
    for path in sorted(SESSIONS_DIR.glob("*.json"), reverse=True):
        with open(path) as f:
            data = json.load(f)
        sessions.append({
            "session_id": data["session_id"],
            "class": data["class"],
            "subject": data["subject"],
            "started_at": data["started_at"],
            "ended_at": data["ended_at"],
            "answer_count": len(data["answers"]),
        })
    return sessions


@app.get("/sessions/{session_id}")
async def get_session(session_id: str):
    path = SESSIONS_DIR / f"{session_id}.json"
    if not path.exists():
        raise HTTPException(status_code=404, detail="Session not found")
    with open(path) as f:
        return json.load(f)


# ==========================
# Gemini helper
# ==========================

async def stream_examiner_reply(chat, user_text: str, websocket: WebSocket, record: dict) -> str:
    """Send one message to Gemini, stream text to the browser, then send audio."""
    await websocket.send_text(json.dumps({"type": "status", "state": "thinking"}))

    full_text = ""
    stream = await chat.send_message_stream(user_text)
    async for chunk in stream:
        text = chunk.text
        if not text:
            continue
        full_text += text
        await websocket.send_text(json.dumps({"type": "question", "text": text}))

    record["transcript"].append({
        "role": "examiner",
        "text": full_text,
        "timestamp": _ts(),
    })

    # Natural-sounding audio; the browser falls back to its own voice if this fails
    try:
        audio = await synthesize(full_text)
        if audio:
            await websocket.send_text(json.dumps({
                "type": "audio",
                "mime": "audio/mpeg",
                "data": base64.b64encode(audio).decode("utf-8"),
            }))
    except Exception as e:
        print(f"[!] TTS failed, falling back to browser voice: {e}")

    await websocket.send_text(json.dumps({"type": "status", "state": "listening"}))
    return full_text


# ==========================
# WebSocket endpoint
# ==========================

@app.websocket("/ws")
async def viva_websocket(websocket: WebSocket):
    await websocket.accept()
    print(f"[+] Browser connected: {websocket.client}")

    # ── 1. Handshake ──
    try:
        raw_init = await websocket.receive_text()
        init = json.loads(raw_init)
    except Exception as e:
        try:
            await websocket.send_text(json.dumps({"type": "error", "text": f"Bad init message: {e}"}))
            await websocket.close()
        except Exception:
            pass
        return

    selected_class = init.get("class", "")
    selected_subject = init.get("subject", "")
    student_name = init.get("student_name", "Student")
    session_id = str(uuid.uuid4())

    print(f"    Session {session_id} · Class {selected_class} · {selected_subject}")

    record = new_session_record(session_id, selected_class, selected_subject)
    record["student_name"] = student_name
    await websocket.send_text(json.dumps({"type": "session_id", "id": session_id}))

    # ── 2. Chat with history ──
    system_prompt = f"""
        You are an experienced school viva examiner.

        Conduct a viva for:
        Class: {selected_class}
        Subject: {selected_subject}

        Instructions:
        1. Ask questions strictly according to the prescribed syllabus.
        2. Ask one question at a time.
        3. Start with easy questions and gradually increase difficulty.
        4. Evaluate every student's answer.
        5. If an answer is incorrect, briefly explain the correct answer.
        6. Ask follow-up questions based on the student's previous answer.
        7. Do not repeat questions.
        8. Conduct approximately 10 questions.
        9. End the viva by saying exactly:
        that concludes the viva
        """

    chat = client.aio.chats.create(
        model=MODEL,
        config=types.GenerateContentConfig(system_instruction=system_prompt),
    )

    last_question = ""

    try:
        # ── 3. Examiner opens the viva ──
        last_question = await stream_examiner_reply(
            chat,
            f"Please begin the viva voce for Class {selected_class} {selected_subject}. "
            f"Introduce yourself briefly and ask the first question.",
            websocket,
            record,
        )

        # ── 4. Answer → reply loop ──
        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue

            if msg.get("type") != "answer":
                continue

            text = msg.get("text", "").strip()
            if not text:
                continue

            record["answers"].append({
                "question": last_question.strip() or "(question pending)",
                "answer": text,
                "timestamp": _ts(),
            })
            record["transcript"].append({
                "role": "student",
                "text": text,
                "timestamp": _ts(),
            })
            save_session(record)   # auto-save after every answer

            last_question = await stream_examiner_reply(chat, text, websocket, record)

            if END_PHRASE in last_question.lower():
                await websocket.send_text(json.dumps({"type": "end"}))
                break

    except WebSocketDisconnect:
        print(f"[-] Browser disconnected: {websocket.client}")
    except Exception as e:
        print(f"[!] Session error: {e}")
        try:
            await websocket.send_text(json.dumps({"type": "error", "text": str(e)}))
        except Exception:
            pass
    finally:
        record["ended_at"] = _ts()
        save_session(record)


@app.get("/evaluation")
async def evalutae_session(path: str):
    # path= SESSIONS_DIR+f"/{session_id}"
    result= await evaluate_viva_session(path)
    return result
    

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)