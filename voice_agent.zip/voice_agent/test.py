import asyncio
import base64
import json
import websockets

API_KEY = "AQ.Ab8RN6JZo0XQ92PRMiDz45_n18p56fyxScUeJGEaN7MAcqBwqw"
import asyncio
import base64
from google import genai


import asyncio
import sounddevice as sd
from google import genai

# ==========================
# Configuration
# ==========================


MODEL = "gemini-3.1-flash-live-preview"

client = genai.Client(api_key=API_KEY)

# Gemini Live PCM audio is generally:
SAMPLE_RATE = 24000
CHANNELS = 1
DTYPE = "int16"


async def receive_loop(session, stream):
    """Receive responses from Gemini."""

    async for response in session.receive():

        if not response.server_content:
            continue

        server = response.server_content

        # User transcript
        if getattr(server, "input_transcription", None):
            print(f"\nYou: {server.input_transcription.text}")

        # Gemini transcript
        if getattr(server, "output_transcription", None):
            print(server.output_transcription.text, end="", flush=True)

        # Audio
        if server.model_turn:
            for part in server.model_turn.parts:

                if getattr(part, "inline_data", None):

                    # Uncomment once to verify
                    # print(part.inline_data.mime_type)

                    audio = part.inline_data.data

                    if len(audio) > 0:
                        stream.write(audio)


async def input_loop(session):
    while True:

        text = await asyncio.to_thread(input, "\n\nYou: ")

        if text.lower() in ("quit", "exit"):
            break

        await session.send_realtime_input(text=text)


async def main():

    config = {
        "response_modalities": ["AUDIO"],
    }

    stream = sd.RawOutputStream(
        samplerate=SAMPLE_RATE,
        channels=CHANNELS,
        dtype=DTYPE,
    )

    stream.start()

    async with client.aio.live.connect(
        model=MODEL,
        config=config,
    ) as session:

        print("Connected to Gemini Live")
        print("Type exit to quit")

        receiver = asyncio.create_task(
            receive_loop(session, stream)
        )

        try:
            await input_loop(session)
        finally:
            receiver.cancel()

            try:
                await receiver
            except asyncio.CancelledError:
                pass

    stream.stop()
    stream.close()


if __name__ == "__main__":
    asyncio.run(main())